import java.security.*;
import javax.crypto.*;

public class Main {

    public static void main(String[] args) throws Exception{
        byte[] data  = "abcdefghijklmnopqrstuvxyz".getBytes("UTF-8");
        //
        // get a key for the HmacMD5 algorithm
        System.out.println( "\nStart generating key" );
        KeyGenerator keyGen = KeyGenerator.getInstance("HmacMD5");
        SecureRandom secureRandom = new SecureRandom();
        int keyBitSize = 256;
        keyGen.init(keyBitSize, secureRandom);
        SecretKey MD5key = keyGen.generateKey();
        System.out.println( "Finish generating key"+ MD5key.getEncoded());
        //
        // get a MAC object and update it with the plaintext
        Mac mac = Mac.getInstance("HmacMD5");
        mac.init(MD5key);
        mac.update(data);
        //
        // print out the provider used and the MAC
        System.out.println( "\n" + mac.getProvider().getInfo() );
        System.out.println( "\nMAC: " );
        System.out.println( new String( mac.doFinal(), "UTF8") );
    }
}
