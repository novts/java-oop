import java.net.*;
import java.util.concurrent.*;
import java.io.*;

public class MultithreadedServer {
    private int port;

    public MultithreadedServer(int port) {
        this.port = port;
    }

    public void listen() {
        int poolSize = 50 * Runtime.getRuntime().availableProcessors();
        ExecutorService tasks = Executors.newFixedThreadPool(poolSize);
        try (ServerSocket listener = new ServerSocket(port)) {
            Socket socket;
            while (true) { // Run until killed
                socket = listener.accept();
                tasks.execute(new ConnectionHandler(socket));
            }
        } catch (IOException ioe) {
            System.err.println("IOException: " + ioe);
            ioe.printStackTrace();
        }
    }

    private class ConnectionHandler implements Runnable {
        private Socket connection;

        public ConnectionHandler(Socket socket) {
            this.connection = socket;
        }

        public void run() {
            try {
                handleConnectionObject(connection);
            } catch (Exception ioe) {
                System.err.println("IOException: " + ioe);
            }
        }

        protected void handleConnection(Socket socket) throws IOException {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String line = in.readLine();
            System.out.println("Получена строка: " + line);
            out.println("От: " + socket.getLocalAddress() + ":" + socket.getLocalPort() + " Ответ: " + line);
          /*  out.println
                    ("HTTP/1.1 200 OK\r\n" +
                            "Content-Type: text/html\r\n" +
                            "\r\n" +
                            "<!DOCTYPE html>\n" +
                            "<html lang=\"en\">\n" +
                            "<head>\n" +
                            " <meta charset=\"utf-8\"/>\n" +
                            " <title>" +"От: "+ socket.getLocalAddress()+":"+socket.getLocalPort()+"</title>\n" +
                            "</head>\n" +
                            "\n" +
                            "<body bgcolor=\"#fdf5e6\">\n" +
                            "<h1 align=\"center\">" + "От: "+ socket.getLocalAddress()+":"+socket.getLocalPort() + "</h1>\n" +
                            line +
                            "></body></html>\\n");
                            */

            socket.close();
        }


    protected void handleConnectionURL(Socket socket) throws IOException {
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String urlStr = in.readLine();
        System.out.println("Получен url: " + urlStr);
        URL url = new URL(urlStr);
      //  BufferedReader inURL = new BufferedReader(new InputStreamReader(url.openStream()));

        URLConnection urlConnection = url.openConnection();
      //  urlConnection.connect();

        BufferedReader inURL = new BufferedReader(new InputStreamReader(
                urlConnection.getInputStream()));

        String inputLine;
        while ((inputLine = inURL.readLine()) != null)
            out.println(inputLine);
        in.close();

        socket.close();
    }

        protected void handleConnectionObject(Socket socket) throws Exception {
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            MessageCommand command = (MessageCommand)in.readObject();
            command.execute(socket);
            in.close();
            socket.close();
        }

}

    public static void main(String[] args) {
        int port = 8080;
        MultithreadedServer server = new MultithreadedServer(port);
        server.listen();
    }

}
