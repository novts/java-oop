import java.net.*;
import java.io.*;

public class UDPServer {

    private String address;
    private int port;

    public UDPServer(String address, int port) {
        this.address=address;
        this.port = port;
    }

    public void send(String message) throws IOException {
        DatagramSocket socket = new DatagramSocket();
        byte[] buffer = message.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(address), port);
        socket.send(packet);
        socket.close();
    }

    public static void main(String[] args){
        String address = "localhost";
        int port = 8080;
        UDPServer server = new UDPServer(address, port);
        try {
            server.send("Hello");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    }
