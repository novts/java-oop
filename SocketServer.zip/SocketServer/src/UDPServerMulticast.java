import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServerMulticast {
    private String address;
    private int port;

    public UDPServerMulticast(String address, int port) {
        this.address=address;
        this.port = port;
    }

    public void broadcast(String message) throws IOException {
        DatagramSocket socket = new DatagramSocket();
        socket.setBroadcast(true);
        byte[] buffer = message.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(address), port);
        socket.send(packet);
        socket.close();
    }

    public static void main(String[] args){
        String address = "230.0.0.0";
        int port = 8080;
        UDPServerMulticast server = new UDPServerMulticast(address, port);
        try {
            server.broadcast("Hello");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
