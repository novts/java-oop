import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class UDPClientMulticast {
    private String address;
    private int port;

    public UDPClientMulticast(String address, int port) {
        this.address=address;
        this.port = port;
    }

    public void listen() {
        try( MulticastSocket socket= new MulticastSocket(port)) {
            InetAddress group = InetAddress.getByName(address);
            socket.joinGroup(group);
            byte[] buf = new byte[256];
            while (true) {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                String received = new String(packet.getData(), 0, packet.getLength());
                System.out.println("Получена строка: " + received);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String address = "230.0.0.0";
        int port = 8080;
        UDPClientMulticast client = new UDPClientMulticast(address, port);
        client.listen();
    }
}
