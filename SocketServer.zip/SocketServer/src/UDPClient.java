import java.net.*;
import java.io.*;

public class UDPClient {
    private int port;

    public UDPClient(int port) {
        this.port = port;
    }

    public void listen() {
        try( DatagramSocket socket= new DatagramSocket(port)) {
            byte[] buf = new byte[256];
            while (true) {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                String received = new String(packet.getData(), 0, packet.getLength());
                System.out.println("Получена строка: " + received);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        int port = 8080;
        UDPClient client = new UDPClient(port);
        client.listen();
    }
}
