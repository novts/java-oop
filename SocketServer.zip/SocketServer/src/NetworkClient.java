import java.net.*;
import java.io.*;

public class NetworkClient {
    private String host;
    private int port;
    private String url;

    public NetworkClient(String host, int port, String url) {
        this.host = host;
        this.port = port;
        this.url = url;
    }
    public void connect() {
        try(Socket client = new Socket(host, port)) {
            handleConnectionObject(client);
        } catch(UnknownHostException uhe) {
            System.err.println("Unknown host: " + host);
        } catch(IOException ioe) {
            System.err.println("IOException: " + ioe);
        }
    }
    protected void handleConnection(Socket client) throws IOException {
        PrintWriter out = new PrintWriter(client.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        out.println(url);
       // String line = in.readLine();
      //  System.out.println("От: " + this.host + " Получена строка: " + line);
        in.lines().forEach(System.out::println);

    }

    protected void handleConnectionObject(Socket client) throws IOException {
        MessageCommand command = new MessageCommand("Hello");
        ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
        BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        out.writeObject(command);
        in.lines().forEach(System.out::println);

    }


    public static void main(String[] args) {
        String host = "localhost";
        int port = 8080;
        String url = "https://docs.oracle.com/javase/8/docs/api/java/net/package-summary.html";
        NetworkClient client = new NetworkClient(host, port, url);
        client.connect();
    }
}
