import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServerBroadcast {
    private String address;
    private int port;

    public UDPServerBroadcast(String address, int port) {
        this.address=address;
        this.port = port;
    }

    public void broadcast(String message) throws IOException {
        DatagramSocket socket = new DatagramSocket();
        socket.setBroadcast(true);
        byte[] buffer = message.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(address), port);
        socket.send(packet);
        socket.close();
    }

    public static void main(String[] args){
        String address = "255.255.255.255";
        int port = 8080;
        UDPServerBroadcast server = new UDPServerBroadcast(address, port);
        try {
            server.broadcast("Hello");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
