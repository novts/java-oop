import java.net.*;
import java.io.*;

public class NetworkServer {

    private int port;

    public NetworkServer(int port) {
        this.port = port;
    }
    public void listen() {
        try(ServerSocket listener = new ServerSocket(port)) {
            Socket socket;
            while(true) { // Run until killed
                socket = listener.accept();
                System.out.println("Получено соединение от: " + socket.getInetAddress()+":"+socket.getPort());
                handleConnection(socket);
            }
        } catch (IOException ioe) {
            System.out.println("IOException: " + ioe);
            ioe.printStackTrace();
        }
    }
    protected void handleConnection(Socket socket) throws IOException{
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String line = in.readLine();
        System.out.println("Получена строка: " + line);
        out.println("От: "+ socket.getLocalAddress()+":"+socket.getLocalPort()+" Ответ: "+ line);
        socket.close();
    }
    public static void main(String[] args) {
        int port = 8080;
        NetworkServer server = new NetworkServer(port);
        server.listen();
    }
}
