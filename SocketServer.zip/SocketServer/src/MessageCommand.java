import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;

public class MessageCommand implements Serializable {

    private String message;

    public MessageCommand(String message){
        this.message=message;
    }
    public void execute(Socket socket)throws IOException {
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        out.println("От: " + socket.getLocalAddress() + ":" + socket.getLocalPort() + " Ответ: " + message);
    }

}
