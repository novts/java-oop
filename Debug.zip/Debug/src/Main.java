public class Main {

    public static int intDiv (int m, int n) {
        int x=m;
        int y=0;
        while (x>=n){
            x=x-n;
            y=y+1;
        }
        return y;
    }

    public static void main(String[] args) {
        intDiv (24, 4);
    }
}
