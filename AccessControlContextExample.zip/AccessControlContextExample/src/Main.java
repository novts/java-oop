import java.security.*;
import java.util.PropertyPermission;

public class Main {

    private static final AccessControlContext NOPERMS_ACC ;
    private static final AccessControlContext PERMS_ACC ;

    static {
        Permissions permsNP = new Permissions();
        ProtectionDomain[] pdNP = { new ProtectionDomain(null, permsNP) };
        NOPERMS_ACC = new AccessControlContext(pdNP);

        Permissions permsP = new Permissions();
        permsP.add(new PropertyPermission("java.home","read"));
        ProtectionDomain[] pdP = { new ProtectionDomain(null, permsP) };
        PERMS_ACC = new AccessControlContext(pdP);
    }

    public static void main(String[] args) {

        Policy.setPolicy(new MyPolicy());

        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }

        System.out.println(System.getSecurityManager());
        AccessController.doPrivileged(
                new PrivilegedAction<Boolean>(){
                    public Boolean run(){
                        System.out.println(System.getProperty("java.home"));
                        return Boolean.TRUE;
                    }
                }
        );

        AccessController.doPrivileged(
                new PrivilegedAction<Boolean>(){
                    public Boolean run(){
                        System.out.println(System.getProperty("java.home"));
                        return Boolean.TRUE;
                    }
                },PERMS_ACC
        );


        AccessController.doPrivileged(
                new PrivilegedAction<Boolean>(){
                    public Boolean run(){
                        System.out.println(System.getProperty("java.home"));
                        return Boolean.TRUE;
                    }
                },NOPERMS_ACC
        );
    }

    public static class MyPolicy extends Policy
    {
        @Override
        public PermissionCollection getPermissions(CodeSource codesource)
        {
            Permissions p = new Permissions();
            p.add(new RuntimePermission("setSecurityManager"));
            return p;
        }
    }

}
