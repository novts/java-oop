import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.text.*;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        Locale currentLocale = Locale.getDefault();
        Locale locale = new Locale("ru", "RU");
        ResourceBundle resourceBundle = ResourceBundle.getBundle("MyBundle", locale);
        System.out.println(resourceBundle.getString("greetings"));

        NumberFormat numberFormat = NumberFormat.getInstance(locale);
        String number = numberFormat.format(100.99);
        System.out.println(number);

        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(locale);
        String currency = currencyFormat.format(100.999);
        System.out.println(currency);

        NumberFormat percentageFormat = NumberFormat.getPercentInstance(locale);
        String percentage = percentageFormat.format(99.999);
        System.out.println(percentage);

        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setDecimalSeparator(';');
        symbols.setGroupingSeparator(':');
        DecimalFormat decimalFormat = new DecimalFormat(resourceBundle.getString("pattern"), symbols);
        String format = decimalFormat.format(123456789.123);
        System.out.println(format);

        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);
        String date = dateFormat.format(new Date());
        System.out.println(date);

        DateFormat timeFormat = DateFormat.getTimeInstance(DateFormat.FULL, locale);
        String time = timeFormat.format(new Date());
        System.out.println(time);

        DateFormat datetimeFormat = DateFormat.getDateTimeInstance(DateFormat.DEFAULT,DateFormat.DEFAULT, locale);
        String datetime = datetimeFormat.format(new Date());
        System.out.println(datetime);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(resourceBundle.getString("datepattern"));
        date = simpleDateFormat.format(new Date());
        System.out.println(date);

        DateFormatSymbols dateFormatSymbols = new DateFormatSymbols(locale);
        dateFormatSymbols.setWeekdays(new String[]{
                "Unused",
                "Sad Sunday",
                "Manic Monday",
                "Thriving Tuesday",
                "Wet Wednesday",
                "Total Thursday",
                "Fat Friday",
                "Super Saturday",
        });
        SimpleDateFormat simpleDateFormatSym = new SimpleDateFormat(resourceBundle.getString("datepattern"),dateFormatSymbols);
        date = simpleDateFormatSym.format(new Date());
        System.out.println(date);

        String[] availableIDs = TimeZone.getAvailableIDs();

        for(String id : availableIDs) {
            System.out.println("id = " + id);
        }

        Calendar calendar = new GregorianCalendar();

        calendar.setTimeZone(TimeZone.getTimeZone("Europe/Samara"));

        calendar.set(Calendar.HOUR_OF_DAY, 9);

        System.out.println(calendar.get(Calendar.HOUR_OF_DAY));

        calendar.setTimeZone(TimeZone.getTimeZone("Europe/Riga"));
        System.out.println(calendar.get(Calendar.HOUR_OF_DAY));

        calendar.setTimeZone(TimeZone.getDefault());
        System.out.println(calendar.get(Calendar.HOUR_OF_DAY));
        System.out.println(calendar.getTime());

        Collator collator = Collator.getInstance(locale);

        String[] words={"апрр","типп","джен"};

        String tmp;
        for (int i = 0; i < words.length; i++) {
            for (int j = i + 1; j < words.length; j++) {
                if (collator.compare(words[i], words[j]) > 0) {
                    tmp = words[i];
                    words[i] = words[j];
                    words[j] = tmp;
                }
            }
        }
        System.out.println(Arrays.toString(words));

        String rules = "< в < б < а";
        try {
            RuleBasedCollator collatorR = new RuleBasedCollator(rules);
            String[] wordsR={"апрр","бипп","вжен"};

            String tmpR;
            for (int i = 0; i < wordsR.length; i++) {
                for (int j = i + 1; j < wordsR.length; j++) {
                    if (collatorR.compare(wordsR[i], wordsR[j]) > 0) {
                        tmpR = wordsR[i];
                        wordsR[i] = wordsR[j];
                        wordsR[j] = tmpR;
                    }
                }
            }
            System.out.println(Arrays.toString(wordsR));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String rulesK = "< с,С < б,Б < а,А";

        RuleBasedCollator ruleBasedCollator = null;
        try {
            ruleBasedCollator = new RuleBasedCollator(rulesK);
            CollationKey[] collationKeys = new CollationKey[3];

            collationKeys[0] = ruleBasedCollator.getCollationKey("апрр");
                    collationKeys[1] = ruleBasedCollator.getCollationKey("сапр");
                            collationKeys[2] = ruleBasedCollator.getCollationKey("босс");

                            Arrays.sort(collationKeys);
            for(CollationKey collationKey : collationKeys) {
                System.out.println(collationKey.getSourceString());
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        System.out.println("Á".equals("\u00C1"));
        System.out.println("A".equals("\u0041"));
        System.out.println(Normalizer.normalize("Á", Normalizer.Form.NFD).equals("\u0041\u0301"));
        System.out.println("Á".equals("\u0041\u0301"));
        System.out.println("Á\u0041\u0301");

        BreakIterator breakIterator = BreakIterator.getWordInstance(locale);
        String str = "Юнико́д стандарт кодирования символов, позволяющий представить знаки почти всех письменных языков ";

        breakIterator.setText(str);

        int boundaryIndex = breakIterator.first();
        while(boundaryIndex != BreakIterator.DONE) {
            int itmp =boundaryIndex;
            boundaryIndex = breakIterator.next();
            if(boundaryIndex>=0) {
                String stmp = str.substring(itmp, boundaryIndex);
                System.out.println(stmp);
            }

        }

        String str1 = "тест";

        try {
            byte[] str2 = str1.getBytes("UTF-8");
            System.out.println(Arrays.toString(str2));
            str2 = str1.getBytes("UTF-16");
            System.out.println(Arrays.toString(str2));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }


    }
}
