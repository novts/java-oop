import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class RMIServer extends UnicastRemoteObject implements RMIInterface{

    protected RMIServer() throws RemoteException {
        super();
    }

    @Override
    public String hello(String name) throws RemoteException {
        System.out.println(name + " is trying to contact!");
        return "Server says hello to " + name;
    }
    public static void main(String[] args){

        try {
            Registry reg = LocateRegistry.createRegistry(8080);
            reg.rebind("//localhost/MyServer", new RMIServer());
            System.out.println("Server ready");

        } catch (Exception e) {
            System.out.println("Server exception: " + e.toString());

        }
    }
}
