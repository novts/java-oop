import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RMIClient {

    private static RMIInterface look_up;

    public static void main(String[] args)
            throws RemoteException, NotBoundException {

        Registry reg = LocateRegistry.getRegistry(8080);
        look_up = (RMIInterface) reg.lookup("//localhost/MyServer");
        String response = look_up.hello("MyName");
        System.out.println("Server response: " + response);

    }
}
