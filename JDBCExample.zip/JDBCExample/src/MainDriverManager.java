import java.sql.*;


public class MainDriverManager {

    public static void main(String[] args) {

        try (
            Connection   conn =
                    DriverManager.getConnection("jdbc:mysql://localhost:3306/ebookshop?useSSL=false", "admin", "1234");
            Statement stmt = conn.createStatement();

            )
            {
                String strSelect = "select title, price, qty from books";
            ResultSet rset = stmt.executeQuery(strSelect);
            while(rset.next()) {
                String title = rset.getString("title");
                double price = rset.getDouble("price");
                int    qty   = rset.getInt("qty");
                System.out.println(title + ", " + price + ", " + qty);
            }

            //----------------------------------------------------------------
                String strUpdate = "update books set price = price*0.7, qty = qty+1 where id = 1";
                stmt.executeUpdate(strUpdate);
                strSelect = "select * from books where id = 1";
                rset = stmt.executeQuery(strSelect);
                while(rset.next()) {
                    System.out.println(rset.getInt("id") + ", "
                            + rset.getString("author") + ", "
                            + rset.getString("title") + ", "
                            + rset.getDouble("price") + ", "
                            + rset.getInt("qty"));
                }

                //-----------------------------------------------------------------------------
                String sqlDelete = "delete from books where id>=3 and id<=4";
                stmt.executeUpdate(sqlDelete);
                String sqlInsert = "insert into books " + "values (3, 'Book','Author' ,11.11, 11),(4, 'Book', 'Author', 33.33, 33)";
                stmt.executeUpdate(sqlInsert);
                strSelect = "select * from books";
                rset = stmt.executeQuery(strSelect);
                while(rset.next()) {
                    System.out.println(rset.getInt("id") + ", "
                            + rset.getString("author") + ", "
                            + rset.getString("title") + ", "
                            + rset.getDouble("price") + ", "
                            + rset.getInt("qty"));
                }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
