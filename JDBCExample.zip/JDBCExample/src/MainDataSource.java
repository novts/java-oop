import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.*;

public class MainDataSource {
    public static void main(String[] args) {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setServerName("localhost");
        dataSource.setPortNumber(3306);
        dataSource.setDatabaseName("ebookshop");
        dataSource.setUser("admin");
        dataSource.setPassword("1234");
        try (
                Connection   conn = dataSource.getConnection();
                Statement stmt = conn.createStatement();
        )
        {
            String strSelect = "select title, price, qty from books";
            ResultSet rset = stmt.executeQuery(strSelect);
            while(rset.next()) {
                String title = rset.getString("title");
                double price = rset.getDouble("price");
                int    qty   = rset.getInt("qty");
                System.out.println(title + ", " + price + ", " + qty);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
