import java.sql.*;
public class MainTransactions {
    public static void main(String[] args) throws SQLException {
        Connection conn = null;
        PreparedStatement updateP = null;
        PreparedStatement updateQ = null;
        PreparedStatement select = null;

        String strUpdateP = "update books set price = ? where id = ?";
        String strUpdateQ = "update books set qty = ? where id = ?";
        String strSelect = "select title, price, qty from books";

        try {
            conn =
                    DriverManager.getConnection("jdbc:mysql://" + "localhost:3306/" + "ebookshop?useSSL=false", "admin", "1234");
            updateP = conn.prepareStatement(strUpdateP);
            updateQ = conn.prepareStatement(strUpdateQ);
            select = conn.prepareStatement(strSelect);


            conn.setAutoCommit(false);
            updateP.setFloat(1, (float) 5.0);
            updateP.setInt(2, 2);
            updateP.executeUpdate();
            if(true){
            throw new SQLException();
            }
            updateQ.setInt(1, 230);
            updateQ.setInt(2, 2);
            updateQ.executeUpdate();
            conn.commit();
            ResultSet rset = select.executeQuery();
            while (rset.next()) {
                String title = rset.getString("title");
                double price = rset.getDouble("price");
                int qty = rset.getInt("qty");
                System.out.println(title + ", " + price + ", " + qty);
            }

        } catch (SQLException e) {
            if (conn != null) {
               //conn.rollback();
            }
            ResultSet rset = select.executeQuery();
            while (rset.next()) {
                String title = rset.getString("title");
                double price = rset.getDouble("price");
                int qty = rset.getInt("qty");
                System.out.println(title + ", " + price + ", " + qty);
            }

        }finally {
            conn.setAutoCommit(true);
            if (updateP != null) {
                updateP.close();
            }
            if (updateQ != null) {
                updateQ.close();
            }
            if (conn != null) {
                conn.close();
            }

        }
    }
}