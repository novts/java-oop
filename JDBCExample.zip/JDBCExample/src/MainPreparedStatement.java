import java.sql.*;

public class MainPreparedStatement {
    public static void main(String[] args) {

        String strUpdate = "update books set price = ?, qty = ? where id = ?";
        String strSelect = "select title, price, qty from books";

        try (
                Connection   conn =
                        DriverManager.getConnection("jdbc:mysql://"+"localhost:3306/"+"ebookshop?useSSL=false", "admin", "1234");
                PreparedStatement  update = conn.prepareStatement(strUpdate);
                PreparedStatement select = conn.prepareStatement(strSelect);

        )
        {

            update.setFloat(1, (float) 9.0);
            update.setInt(2,300);
            update.setInt(3,2);
            update.executeUpdate();
            ResultSet rset = select.executeQuery();
            while(rset.next()) {
                String title = rset.getString("title");
                double price = rset.getDouble("price");
                int    qty   = rset.getInt("qty");
                System.out.println(title + ", " + price + ", " + qty);
            }

            } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
