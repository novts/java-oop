/**
 * Created by Тимур on 08.09.2017.
 */
public class Square extends Figure{

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    private double length;

    @Override
    public double area() {
        return length * length;
    }
}
