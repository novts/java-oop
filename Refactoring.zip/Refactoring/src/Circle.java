/**
 * Created by Тимур on 08.09.2017.
 */
public class Circle extends Figure{
    public static double PI=3.14;

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    private double radius;

    @Override
    public double area() {
        return radius * radius * PI;
    }
}
