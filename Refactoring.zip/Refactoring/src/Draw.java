public class Draw {

    static double paintNeeded(Circle circle, Square square, double spreadRate, int nCoats, double radius, int nCircles, double length, int nSquares){

        circle.setRadius(radius);
        square.setLength(length);

        return nCoats*(nCircles * circle.area() + nSquares * square.area())/spreadRate;
    }

    public static void main(String[] args) {

    }
}
