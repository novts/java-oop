/**
 * Created by Тимур on 08.09.2017.
 */
public abstract class Figure {
    public abstract double area();
}
